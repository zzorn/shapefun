Project documentation is available at:
http://code.google.com/p/simplex3d/wiki/MathLibrary


Runtime requirements:
  - Scala 2.8.0.final or higher.

Build requirements:
  - Ant 1.7 or higher.
  - SCALA_HOME set to Scala 2.8.0.final or higher.

To build the project:
  1) open a console,
  2) cd into the project directory,
  3) type: ant release-bin
